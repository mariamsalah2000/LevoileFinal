<?php 

return [
    'view' => 'two_factor_auth.2fa_verify',
];