

<?php $__env->startSection('content'); ?>
<section class="section">
  <div class="row">
    <div class="col-lg-8 offset-2">
      <div class="card">
        <div class="card-body">
          <h5 class="card-title">Real-time notifications demo</h5>
          <!-- General Form Elements -->
          <div class="row mb-3 mt-4">
            <label class="col-sm-4 col-form-label">Message</label>
            <div class="col-sm-10">
              <input type="text" class="form-control" id="message" name="message">
            </div>
          </div>
          <div class="row mb-3 mt-4">
            <label class="col-sm-4 col-form-label">Select Account</label>
            <div class="col-sm-10">
              <select name="user" id="user" class="form-control">
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                  <option value="<?php echo e($user['id']); ?>"><?php echo e($user['name']); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>
          </div>
          <div class="row mb-3">
            <div class="col-sm-12 text-center">
              <button id="submit" type="submit" class="btn btn-primary">Send Notification</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
  <script>
    $(document).ready(function () {
      $('#submit').click(function (e) {
        e.preventDefault();
        
        //Previous code
        /* 
        
        var obj = {
          user: $('#user').val(),
          message: $('#message').val()
        }
        socket.emit('sendNotificationToUser', obj);
        
        */

        //Revised code
        $.ajax({
          type: 'POST',
          url: "<?php echo e(route('send.web.message')); ?>",
          async: false,
          data: {
            "user" : $('#user').val(), 
            "message": $('#message').val(), 
            "_token": "<?php echo e(csrf_token()); ?>" //For CSRF validation
          },
          success: function (res) {
            console.log('sent message');
          }
        });
      })
    });
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ShopfiyPro\shopify_project\resources\views/superadmin/notifications/index.blade.php ENDPATH**/ ?>